
var bodyParser = require('body-parser');
var path = require('path');
var loginUser ;
var reportData;

module.exports = function(app) {
    
    app.use(bodyParser.json());
    app.use(bodyParser.urlencoded({ extended: true }));

    app.post('/search', function(req,res) {
        if (req.body.city === 'Bangalore')
        {
            if (req.body.location === 'IN')
            {
                res.render('bng-in');
            }
        }
        if (req.body.city === 'Delhi')
        {
            if (req.body.location === 'CP')
            {
                res.render('dli-cp');
            }
            if (req.body.location === 'DK')
            {
                res.render('dli-dk');
            }
        }
    });

    app.post('/home', function(req,res) {
        res.render('index');
    });

};